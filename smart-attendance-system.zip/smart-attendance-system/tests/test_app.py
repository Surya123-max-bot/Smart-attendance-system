import os
import sqlite3
import tempfile
import unittest
from datetime import datetime, timedelta

import numpy as np

import db
from app import create_app


class AppTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.app = create_app({"DATABASE": self.path, "TESTING": True, "SECRET_KEY": "t"})
        self.c = self.app.test_client()
        self.c.post("/login", data={"username": "admin", "password": "admin123"})

    def tearDown(self):
        os.remove(self.path)

    def _setup_session(self, cls=""):
        self.c.post("/students", data={"roll_no": "R1", "name": "Asha", "class_name": "A"})
        self.c.post("/students", data={"roll_no": "R2", "name": "Ben", "class_name": "A"})
        self.c.post("/sessions", data={"title": "Maths", "class_name": cls, "minutes": 10})
        conn = db.connect(self.path)
        row = conn.execute("SELECT * FROM sessions").fetchone()
        conn.close()
        return row

    def test_login_required(self):
        anon = self.app.test_client()
        self.assertEqual(anon.get("/dashboard").status_code, 302)

    def test_bad_login(self):
        anon = self.app.test_client()
        r = anon.post("/login", data={"username": "admin", "password": "nope"})
        self.assertIn(b"Invalid", r.data)

    def test_mark_and_duplicate(self):
        s = self._setup_session()
        anon = self.app.test_client()
        r = anon.post("/mark", data={"roll_no": "R1", "code": s["code"]}, follow_redirects=True)
        self.assertIn(b"marked present", r.data)
        r = anon.post("/mark", data={"roll_no": "R1", "code": s["code"]}, follow_redirects=True)
        self.assertIn(b"already marked", r.data)

    def test_wrong_code(self):
        self._setup_session()
        r = self.app.test_client().post("/mark", data={"roll_no": "R1", "code": "000000"},
                                        follow_redirects=True)
        self.assertIn(b"Unknown", r.data)

    def test_expired_session(self):
        s = self._setup_session()
        conn = db.connect(self.path)
        past = (datetime.now() - timedelta(minutes=1)).isoformat(timespec="seconds")
        conn.execute("UPDATE sessions SET expires_at=?", (past,))
        conn.commit()
        conn.close()
        r = self.app.test_client().post("/mark", data={"roll_no": "R1", "code": s["code"]},
                                        follow_redirects=True)
        self.assertIn(b"closed", r.data)

    def test_report_and_csv(self):
        s = self._setup_session()
        self.app.test_client().post("/mark", data={"roll_no": "R1", "code": s["code"]})
        r = self.c.get(f"/report/{s['id']}.csv")
        text = r.data.decode()
        self.assertIn("R1,Asha,present", text)
        self.assertIn("R2,Ben,absent", text)
        self.assertEqual(self.c.get(f"/report?session={s['id']}").status_code, 200)

    def test_wrong_class(self):
        self.c.post("/students", data={"roll_no": "R9", "name": "Zed", "class_name": "B"})
        self.c.post("/sessions", data={"title": "Art", "class_name": "A", "minutes": 5})
        conn = db.connect(self.path)
        code = conn.execute("SELECT code FROM sessions").fetchone()[0]
        conn.close()
        r = self.app.test_client().post("/mark", data={"roll_no": "R9", "code": code},
                                        follow_redirects=True)
        self.assertIn(b"not for your class", r.data)


class FaceSmokeTest(unittest.TestCase):
    def test_train_and_identify(self):
        import cv2
        import face
        rng = np.random.default_rng(0)
        with tempfile.TemporaryDirectory() as d:
            for sid, base in ((1, 60), (2, 190)):
                os.makedirs(os.path.join(d, str(sid)))
                for i in range(6):
                    img = np.clip(rng.normal(base, 15, face.FACE_SIZE[::-1]), 0, 255).astype("uint8")
                    img[:, : 40 + 30 * sid] = 255 - base
                    cv2.imwrite(os.path.join(d, str(sid), f"{i}.jpg"), img)
            rec = face.train(d, os.path.join(d, "m.yml"))
            probe = cv2.imread(os.path.join(d, "1", "0.jpg"), cv2.IMREAD_GRAYSCALE)
            self.assertEqual(face.identify(rec, probe, threshold=1000), 1)


if __name__ == "__main__":
    unittest.main()
