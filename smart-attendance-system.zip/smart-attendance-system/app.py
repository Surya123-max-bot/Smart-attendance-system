"""Smart Attendance System - Flask web app."""
import csv
import io
import os
import secrets
import sqlite3
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, Response, flash, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import db


def create_app(config=None):
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-change-me"),
        DATABASE=os.environ.get("DATABASE", "attendance.db"),
        ADMIN_USER=os.environ.get("ADMIN_USER", "admin"),
        ADMIN_PASS_HASH=generate_password_hash(os.environ.get("ADMIN_PASS", "admin123")),
    )
    if config:
        app.config.update(config)
    db.init_db(app.config["DATABASE"])
    app.teardown_appcontext(db.close_db)

    def login_required(view):
        @wraps(view)
        def wrapped(*a, **kw):
            if not session.get("admin"):
                return redirect(url_for("login"))
            return view(*a, **kw)
        return wrapped

    # ---------- auth ----------
    @app.route("/")
    def index():
        return redirect(url_for("dashboard" if session.get("admin") else "mark"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            ok = (request.form["username"] == app.config["ADMIN_USER"]
                  and check_password_hash(app.config["ADMIN_PASS_HASH"], request.form["password"]))
            if ok:
                session["admin"] = True
                return redirect(url_for("dashboard"))
            flash("Invalid username or password.", "error")
        return render_template("login.html")

    @app.route("/logout")
    def logout():
        session.clear()
        return redirect(url_for("login"))

    # ---------- dashboard ----------
    @app.route("/dashboard")
    @login_required
    def dashboard():
        conn = db.get_db()
        stats = {
            "students": conn.execute("SELECT COUNT(*) FROM students").fetchone()[0],
            "sessions": conn.execute("SELECT COUNT(*) FROM sessions").fetchone()[0],
            "marks": conn.execute("SELECT COUNT(*) FROM attendance").fetchone()[0],
        }
        recent = conn.execute(
            "SELECT s.name, s.roll_no, ss.title, a.marked_at, a.method FROM attendance a "
            "JOIN students s ON s.id=a.student_id JOIN sessions ss ON ss.id=a.session_id "
            "ORDER BY a.id DESC LIMIT 8").fetchall()
        return render_template("dashboard.html", stats=stats, recent=recent)

    # ---------- students ----------
    @app.route("/students", methods=["GET", "POST"])
    @login_required
    def students():
        conn = db.get_db()
        if request.method == "POST":
            roll = request.form["roll_no"].strip()
            name = request.form["name"].strip()
            cls = request.form.get("class_name", "").strip()
            if not roll or not name:
                flash("Roll number and name are required.", "error")
            else:
                try:
                    conn.execute("INSERT INTO students (roll_no,name,class_name) VALUES (?,?,?)",
                                 (roll, name, cls))
                    conn.commit()
                    flash(f"Added {name}.", "ok")
                except sqlite3.IntegrityError:
                    flash("That roll number already exists.", "error")
            return redirect(url_for("students"))
        rows = conn.execute("SELECT * FROM students ORDER BY class_name, roll_no").fetchall()
        return render_template("students.html", students=rows)

    @app.route("/students/<int:sid>/delete", methods=["POST"])
    @login_required
    def delete_student(sid):
        conn = db.get_db()
        conn.execute("DELETE FROM students WHERE id=?", (sid,))
        conn.commit()
        flash("Student removed.", "ok")
        return redirect(url_for("students"))

    # ---------- sessions ----------
    @app.route("/sessions", methods=["GET", "POST"])
    @login_required
    def sessions():
        conn = db.get_db()
        if request.method == "POST":
            title = request.form["title"].strip() or "Class"
            cls = request.form.get("class_name", "").strip()
            minutes = max(1, min(int(request.form.get("minutes", 10) or 10), 240))
            now = datetime.now()
            code = f"{secrets.randbelow(10**6):06d}"
            conn.execute(
                "INSERT INTO sessions (title,class_name,code,created_at,expires_at) VALUES (?,?,?,?,?)",
                (title, cls, code, now.isoformat(timespec="seconds"),
                 (now + timedelta(minutes=minutes)).isoformat(timespec="seconds")))
            conn.commit()
            flash(f"Session started. Attendance code: {code}", "ok")
            return redirect(url_for("sessions"))
        rows = conn.execute("SELECT * FROM sessions ORDER BY id DESC").fetchall()
        return render_template("sessions.html", sessions=rows, now=datetime.now().isoformat())

    # ---------- student check-in (public) ----------
    @app.route("/mark", methods=["GET", "POST"])
    def mark():
        if request.method == "POST":
            roll = request.form["roll_no"].strip()
            code = request.form["code"].strip()
            conn = db.get_db()
            student = conn.execute("SELECT * FROM students WHERE roll_no=?", (roll,)).fetchone()
            sess = conn.execute("SELECT * FROM sessions WHERE code=? ORDER BY id DESC",
                                (code,)).fetchone()
            now = datetime.now()
            if not student or not sess:
                flash("Unknown roll number or code.", "error")
            elif now > datetime.fromisoformat(sess["expires_at"]):
                flash("This session has closed.", "error")
            elif sess["class_name"] and sess["class_name"] != student["class_name"]:
                flash("This session is not for your class.", "error")
            elif db.mark_attendance(conn, student["id"], sess["id"], "code", now):
                flash(f"Thanks {student['name']}, you're marked present for {sess['title']}.", "ok")
            else:
                flash("You're already marked for this session.", "error")
            return redirect(url_for("mark"))
        return render_template("mark.html")

    # ---------- reports ----------
    def session_rows(conn, sid):
        sess = conn.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
        if not sess:
            return None, [], []
        present = conn.execute(
            "SELECT s.roll_no, s.name, a.marked_at, a.method FROM attendance a "
            "JOIN students s ON s.id=a.student_id WHERE a.session_id=? ORDER BY s.roll_no",
            (sid,)).fetchall()
        q = ("SELECT roll_no, name FROM students WHERE id NOT IN "
             "(SELECT student_id FROM attendance WHERE session_id=?)")
        args = [sid]
        if sess["class_name"]:
            q += " AND class_name=?"
            args.append(sess["class_name"])
        absent = conn.execute(q + " ORDER BY roll_no", args).fetchall()
        return sess, present, absent

    @app.route("/report")
    @login_required
    def report():
        conn = db.get_db()
        all_sessions = conn.execute("SELECT * FROM sessions ORDER BY id DESC").fetchall()
        sid = request.args.get("session", type=int)
        sess, present, absent = session_rows(conn, sid) if sid else (None, [], [])
        summary = conn.execute(
            "SELECT s.roll_no, s.name, s.class_name, "
            "(SELECT COUNT(*) FROM attendance a WHERE a.student_id=s.id) AS attended, "
            "(SELECT COUNT(*) FROM sessions x WHERE x.class_name='' OR x.class_name=s.class_name) AS total "
            "FROM students s ORDER BY s.roll_no").fetchall()
        return render_template("report.html", sessions=all_sessions, sess=sess,
                               present=present, absent=absent, summary=summary)

    @app.route("/report/<int:sid>.csv")
    @login_required
    def export_csv(sid):
        sess, present, absent = session_rows(db.get_db(), sid)
        if not sess:
            return "Not found", 404
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["roll_no", "name", "status", "marked_at", "method"])
        for r in present:
            w.writerow([r["roll_no"], r["name"], "present", r["marked_at"], r["method"]])
        for r in absent:
            w.writerow([r["roll_no"], r["name"], "absent", "", ""])
        return Response(buf.getvalue(), mimetype="text/csv", headers={
            "Content-Disposition": f"attachment; filename=attendance_session_{sid}.csv"})

    return app


if __name__ == "__main__":
    create_app().run(host="0.0.0.0", port=5000, debug=True)
