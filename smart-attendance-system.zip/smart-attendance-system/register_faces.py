"""Capture face samples for a student, then (re)train the model.

    python register_faces.py --roll 21CS001
"""
import argparse
import os

import db
import face

ap = argparse.ArgumentParser()
ap.add_argument("--roll", required=True, help="student roll number (must already exist)")
ap.add_argument("--samples", type=int, default=30)
ap.add_argument("--db", default=os.environ.get("DATABASE", "attendance.db"))
a = ap.parse_args()

conn = db.connect(a.db)
st = conn.execute("SELECT * FROM students WHERE roll_no=?", (a.roll,)).fetchone()
if not st:
    raise SystemExit(f"No student with roll number {a.roll}. Add them in the web app first.")
n = face.capture_samples(st["id"], a.samples)
print(f"Saved {n} samples for {st['name']}.")
face.train()
print("Model trained -> face_model.yml")
