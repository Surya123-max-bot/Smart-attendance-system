"""Live webcam attendance. Marks students present for an open session.

    python face_attendance.py --session 1
Press q to quit.
"""
import argparse
import os
from collections import defaultdict
from datetime import datetime

import cv2

import db
import face

CONFIRM_FRAMES = 5  # a face must be recognised this many times before marking

ap = argparse.ArgumentParser()
ap.add_argument("--session", type=int, required=True)
ap.add_argument("--db", default=os.environ.get("DATABASE", "attendance.db"))
ap.add_argument("--camera", type=int, default=0)
a = ap.parse_args()

conn = db.connect(a.db)
sess = conn.execute("SELECT * FROM sessions WHERE id=?", (a.session,)).fetchone()
if not sess:
    raise SystemExit("Session not found.")
if datetime.now() > datetime.fromisoformat(sess["expires_at"]):
    raise SystemExit("That session has already closed.")

rec = face.load_recognizer()
cap = cv2.VideoCapture(a.camera)
streak, done = defaultdict(int), set()

while True:
    ok, frame = cap.read()
    if not ok:
        break
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    for box in face.detect_faces(gray):
        sid = face.identify(rec, face.prepare(gray, box))
        x, y, w, h = box
        text, color = "Unknown", (0, 0, 220)
        if sid is not None:
            st = conn.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()
            if st and (not sess["class_name"] or st["class_name"] == sess["class_name"]):
                text, color = st["name"], (0, 200, 0)
                streak[sid] += 1
                if streak[sid] >= CONFIRM_FRAMES and sid not in done:
                    done.add(sid)
                    if db.mark_attendance(conn, sid, sess["id"], "face", datetime.now()):
                        print(f"Marked present: {st['name']} ({st['roll_no']})")
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
        cv2.putText(frame, text, (x, y - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
    cv2.imshow("Smart Attendance - press q to quit", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break
cap.release()
cv2.destroyAllWindows()
