"""Face recognition helpers built on OpenCV's LBPH recognizer."""
import os

import cv2
import numpy as np

DATA_DIR = "face_data"
MODEL_PATH = "face_model.yml"
FACE_SIZE = (200, 200)
_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")


def detect_faces(gray):
    return _cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(80, 80))


def prepare(gray, box=None):
    face = gray if box is None else gray[box[1]:box[1] + box[3], box[0]:box[0] + box[2]]
    return cv2.equalizeHist(cv2.resize(face, FACE_SIZE))


def capture_samples(student_id, count=30, camera=0):
    """Capture `count` face crops from the webcam into face_data/<student_id>/."""
    folder = os.path.join(DATA_DIR, str(student_id))
    os.makedirs(folder, exist_ok=True)
    cap = cv2.VideoCapture(camera)
    saved = 0
    while saved < count:
        ok, frame = cap.read()
        if not ok:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        for box in detect_faces(gray)[:1]:
            cv2.imwrite(os.path.join(folder, f"{saved}.jpg"), prepare(gray, box))
            saved += 1
            x, y, w, h = box
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 200, 0), 2)
        cv2.putText(frame, f"{saved}/{count}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 200, 0), 2)
        cv2.imshow("Registering face - press q to stop", frame)
        if cv2.waitKey(150) & 0xFF == ord("q"):
            break
    cap.release()
    cv2.destroyAllWindows()
    return saved


def train(data_dir=DATA_DIR, model_path=MODEL_PATH):
    """Train on every face_data/<student_id>/*.jpg. Labels are student ids."""
    images, labels = [], []
    for name in os.listdir(data_dir):
        folder = os.path.join(data_dir, name)
        if not (os.path.isdir(folder) and name.isdigit()):
            continue
        for f in os.listdir(folder):
            img = cv2.imread(os.path.join(folder, f), cv2.IMREAD_GRAYSCALE)
            if img is not None:
                images.append(cv2.resize(img, FACE_SIZE))
                labels.append(int(name))
    if not images:
        raise RuntimeError("No face images found. Register students first.")
    rec = cv2.face.LBPHFaceRecognizer_create()
    rec.train(images, np.array(labels))
    rec.write(model_path)
    return rec


def load_recognizer(model_path=MODEL_PATH):
    rec = cv2.face.LBPHFaceRecognizer_create()
    rec.read(model_path)
    return rec


def identify(recognizer, face_img, threshold=65.0):
    """Return student id or None. Lower LBPH confidence = better match."""
    label, confidence = recognizer.predict(face_img)
    return label if confidence < threshold else None
