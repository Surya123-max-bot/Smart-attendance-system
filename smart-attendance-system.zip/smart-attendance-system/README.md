# Smart Attendance System

A web-based attendance system with two ways to check in:

- **Session code** – the teacher starts a timed session and shares a 6-digit code; students enter their roll number + code on their phones.
- **Face recognition** – a webcam script (OpenCV LBPH) recognises registered students and marks them automatically.

Everything is stored in one SQLite file, with reports, absentee lists and CSV export.

## Features

- Admin login, student management, class/section support
- Timed sessions with auto-expiry; duplicate and wrong-class check-ins blocked
- Per-session present/absent report, CSV download, overall attendance % per student (red below 75%)
- Mobile-friendly UI with dark mode
- Face registration, training and live recognition (needs a webcam)

## Setup

```bash
git clone https://github.com/<your-username>/smart-attendance-system.git
cd smart-attendance-system
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000. Default admin login: `admin` / `admin123`.
**Change it** with environment variables before real use:

```bash
export ADMIN_USER=teacher ADMIN_PASS='a-strong-password' SECRET_KEY='long-random-string'
```

## Usage

1. Log in → **Students** → add students.
2. **Sessions** → start a session → share the code. Students open `/mark`.
3. **Reports** → pick a session to see present/absent and download CSV.

### Face recognition (optional)

```bash
python register_faces.py --roll 21CS001      # captures 30 samples, retrains model
python face_attendance.py --session 1        # live camera, press q to quit
```

A face must be recognised in 5 consecutive frames before attendance is marked. Tune `threshold` in `face.identify` if you get false matches (lower = stricter).

## Tests

```bash
python -m unittest discover -s tests -v
```

## Project structure

```
app.py                Flask app (routes, auth, reports)
db.py                 SQLite schema + helpers
face.py               OpenCV face detection / training / recognition
register_faces.py     capture face samples for a student
face_attendance.py    live webcam attendance
templates/, static/   UI
tests/                unit tests
```

## Notes and limitations

- LBPH is lightweight but not spoof-proof (a photo can fool it). For stronger security, swap `face.py` for a deep-learning model and add liveness checks.
- Code check-in can be shared between friends; use short session windows.
- No CSRF protection on forms; add Flask-WTF before exposing to the public internet.
- Face images are biometric data; get consent and follow your local privacy rules.

## License

MIT
